# -*- coding: utf-8 -*-
"""Top-level package for amazon-textract-response-parser."""

__version__ = '0.1.40'
